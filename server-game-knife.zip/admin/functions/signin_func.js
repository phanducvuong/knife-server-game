exports.SECRETE           = 'sgdsuu56jnkjasdsahgfkvkvsdg';

exports.ARR_ADMIN         = [
  'nhut.lm@yeah1.vn', 'thu.phovo@gmail.com', 'ducvuong.dev@gmail.com'
];