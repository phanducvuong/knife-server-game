env = {
  http      : 'http://',
  rows_show : 20,
  max_page  : 6                           //số trang hiện tối đa. Nếu vượt quá max_page -> hiện dấu ... + page cuối
}