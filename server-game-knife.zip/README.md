- ## NODEJS

  ```bash
  npm install
  npm run dev                  //start with dev enviroment
  npm run prod                 //start with production enviroment
  ```

- ## FILE CONFIG

     ```bash
    -  file ./config_prod.js : dev config enviroment
    -  file ./config_dev.js : production config enviroment
    ``` 